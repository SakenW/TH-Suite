#!/usr/bin/env python
"""
MC L10n 数据库管理工具
提供数据库维护、验证和统计功能
"""

import argparse
import json
import sqlite3
import sys
from pathlib import Path
from typing import Any

# 添加backend目录到路径以导入核心模块
backend_path = Path(__file__).parent.parent / "backend"
sys.path.insert(0, str(backend_path))

from core.mc_database import Database


class DatabaseManager:
    """数据库管理器"""

    def __init__(self, db_path: str = "mc_l10n.db"):
        self.db_path = Path(db_path)
        self.db = Database(str(self.db_path))

    def verify_structure(self) -> dict[str, Any]:
        """验证数据库结构"""
        results = {"tables": {}, "indexes": {}, "views": {}, "status": "ok"}

        with self.db.get_connection() as conn:
            cursor = conn.cursor()

            # 检查表
            expected_tables = [
                "projects",
                "mods",
                "language_files",
                "translation_entries",
                "scan_cache",
                "glossary",
                "work_queue",
                "scan_progress",
                "sync_log",
                "mod_metadata",
            ]

            cursor.execute("""
                SELECT name FROM sqlite_master
                WHERE type='table' AND name NOT LIKE 'sqlite_%'
            """)
            actual_tables = {row[0] for row in cursor.fetchall()}

            for table in expected_tables:
                results["tables"][table] = table in actual_tables
                if table not in actual_tables:
                    results["status"] = "missing_tables"

            # 检查索引数量
            cursor.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='index'")
            results["indexes"]["count"] = cursor.fetchone()[0]

            # 检查视图
            cursor.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='view'")
            results["views"]["count"] = cursor.fetchone()[0]

        return results

    def get_statistics(self) -> dict[str, Any]:
        """获取数据库统计信息"""
        stats = {}

        with self.db.get_connection() as conn:
            cursor = conn.cursor()

            # 基本统计
            tables = [
                "projects",
                "mods",
                "language_files",
                "translation_entries",
                "scan_cache",
                "glossary",
                "work_queue",
                "scan_progress",
            ]

            for table in tables:
                try:
                    cursor.execute(f"SELECT COUNT(*) FROM {table}")
                    stats[table] = cursor.fetchone()[0]
                except sqlite3.OperationalError:
                    stats[table] = 0

            # 语言分布
            try:
                cursor.execute("""
                    SELECT language_code, COUNT(*) as count
                    FROM language_files
                    GROUP BY language_code
                    ORDER BY count DESC
                    LIMIT 10
                """)
                stats["languages"] = {row[0]: row[1] for row in cursor.fetchall()}
            except sqlite3.Error:
                stats["languages"] = {}

            # 翻译状态
            try:
                cursor.execute("""
                    SELECT status, COUNT(*) as count
                    FROM translation_entries
                    GROUP BY status
                """)
                stats["translation_status"] = {
                    row[0]: row[1] for row in cursor.fetchall()
                }
            except sqlite3.Error:
                stats["translation_status"] = {}

            # 数据库大小
            if self.db_path.exists():
                stats["size_mb"] = self.db_path.stat().st_size / 1024 / 1024

        return stats

    def cleanup_cache(self, days: int = 7) -> int:
        """清理过期缓存"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()

            # 清理扫描缓存
            cursor.execute(
                """
                DELETE FROM scan_cache
                WHERE datetime(cached_at, '+' || ? || ' days') < datetime('now')
            """,
                (days,),
            )

            deleted = cursor.rowcount
            conn.commit()

        return deleted

    def vacuum(self):
        """优化数据库（VACUUM）"""
        with self.db.get_connection() as conn:
            conn.execute("VACUUM")
            conn.execute("ANALYZE")

    def export_data(self, output_file: str):
        """导出数据为JSON"""
        data = {}

        with self.db.get_connection() as conn:
            cursor = conn.cursor()

            # 导出MOD信息
            cursor.execute("""
                SELECT mod_id, mod_name, version, file_path, language_count, total_keys
                FROM mods
            """)
            data["mods"] = [
                {
                    "mod_id": row[0],
                    "mod_name": row[1],
                    "version": row[2],
                    "file_path": row[3],
                    "language_count": row[4],
                    "total_keys": row[5],
                }
                for row in cursor.fetchall()
            ]

            # 导出语言文件
            cursor.execute("""
                SELECT mod_id, language_code, file_path, entry_count
                FROM language_files
            """)
            data["language_files"] = [
                {
                    "mod_id": row[0],
                    "language_code": row[1],
                    "file_path": row[2],
                    "entry_count": row[3],
                }
                for row in cursor.fetchall()
            ]

        # 写入文件
        output_path = Path(output_file)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

        return output_path

    def show_summary(self):
        """显示数据库摘要"""
        print("=" * 60)
        print("  MC L10n 数据库摘要")
        print("=" * 60)

        # 结构验证
        structure = self.verify_structure()
        print(f"\n📋 数据库结构: {structure['status'].upper()}")
        print(
            f"  表数量: {sum(1 for v in structure['tables'].values() if v)}/{len(structure['tables'])}"
        )
        print(f"  索引数量: {structure['indexes']['count']}")
        print(f"  视图数量: {structure['views']['count']}")

        # 统计信息
        stats = self.get_statistics()
        print("\n📊 数据统计:")
        print(f"  项目数: {stats.get('projects', 0)}")
        print(f"  MOD数: {stats.get('mods', 0)}")
        print(f"  语言文件数: {stats.get('language_files', 0)}")
        print(f"  翻译条目数: {stats.get('translation_entries', 0)}")
        print(f"  缓存条目数: {stats.get('scan_cache', 0)}")
        print(f"  数据库大小: {stats.get('size_mb', 0):.2f} MB")

        # 语言分布
        if stats.get("languages"):
            print("\n🌍 语言分布 (Top 5):")
            for lang, count in list(stats["languages"].items())[:5]:
                print(f"  {lang}: {count} 个文件")

        # 翻译状态
        if stats.get("translation_status"):
            print("\n📝 翻译状态:")
            total = sum(stats["translation_status"].values())
            for status, count in stats["translation_status"].items():
                percentage = (count / total * 100) if total > 0 else 0
                print(f"  {status}: {count} ({percentage:.1f}%)")

        print("=" * 60)


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="MC L10n 数据库管理工具")
    parser.add_argument("--db", default="mc_l10n.db", help="数据库文件路径")

    subparsers = parser.add_subparsers(dest="command", help="可用命令")

    # 摘要命令
    subparsers.add_parser("summary", help="显示数据库摘要")

    # 验证命令
    subparsers.add_parser("verify", help="验证数据库结构")

    # 清理命令
    cleanup_parser = subparsers.add_parser("cleanup", help="清理过期缓存")
    cleanup_parser.add_argument("--days", type=int, default=7, help="保留天数")

    # 优化命令
    subparsers.add_parser("vacuum", help="优化数据库（VACUUM）")

    # 导出命令
    export_parser = subparsers.add_parser("export", help="导出数据为JSON")
    export_parser.add_argument("output", help="输出文件路径")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    # 创建管理器
    manager = DatabaseManager(args.db)

    # 执行命令
    if args.command == "summary":
        manager.show_summary()

    elif args.command == "verify":
        result = manager.verify_structure()
        print(f"数据库结构验证: {result['status'].upper()}")
        if result["status"] != "ok":
            print("缺失的表:")
            for table, exists in result["tables"].items():
                if not exists:
                    print(f"  - {table}")

    elif args.command == "cleanup":
        deleted = manager.cleanup_cache(args.days)
        print(f"清理了 {deleted} 条过期缓存")

    elif args.command == "vacuum":
        print("正在优化数据库...")
        manager.vacuum()
        print("✅ 数据库优化完成")

    elif args.command == "export":
        output_path = manager.export_data(args.output)
        print(f"✅ 数据已导出到: {output_path}")


if __name__ == "__main__":
    main()
